import w6_module
w6_module.pisagor(5,12)
w6_module.taxi(0.15)
w6_module.sorted_list(1,5,2)
w6_module.license_plt()
