c=input(" Enter the temp in Celcius : ")
f=float(c)*(9/5)+32.0
print("Temp in Fahrenheit : ",f)
