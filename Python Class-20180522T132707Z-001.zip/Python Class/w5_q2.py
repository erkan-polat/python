def sum_of_list(lst):
    total=1
    for i in range(0,len(lst)):
        total=total*lst[i]
    return total
