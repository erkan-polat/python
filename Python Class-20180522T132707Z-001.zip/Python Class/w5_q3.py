def fakt(x):
    fak=1
    for i in range(x,0,-1):
        fak=fak*i
    return fak
