number=input("Input a number = ")
for i in range(1,11):
    print(number+' x '+str(i)+' = '+str(int(number)*i))
