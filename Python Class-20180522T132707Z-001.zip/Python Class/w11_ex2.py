class Rect():
    def __init__(self,width,length):
        self.width=width
        self.length=length
    def area(self):
        print("Area of rectangle is : " + str(self.width*self.length))
