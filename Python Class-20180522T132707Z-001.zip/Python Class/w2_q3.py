a=input("Lenght of rect ? :")
b=input("Width of rect ? :")
print("Area of rect = ",int(a)*int(b))
