lst=['python','c','java']
print(lst[0])
print(lst[1])
print(lst[2])
