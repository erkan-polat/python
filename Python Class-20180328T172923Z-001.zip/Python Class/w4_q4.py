total=0
for i in range(0,2001,2):
    total=total-i
for i in range(1,2001,2):
    total=total+i
print(total)
