careers=["engineer","doctor","teacher","nurse"]
print("İndex of doctor = ",careers.index("doctor"))
print("Is doctor in the list  ? :" , "doctor" in careers )
careers.append("police")
print("Append 'police' to careers :  " ,careers )
careers.insert(0,"technicer")
print("İnsert 'technicer' at the beginning : ",careers)

